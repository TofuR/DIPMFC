﻿//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ 生成的包含文件。
// 供 My11121115ddf.rc 使用
//
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDR_MAINFRAME                   128
#define IDR_My11121115ddfTYPE           130
#define IDD_DLG_HISTO                   310
#define IDD_DLG_ADJWIN                  312
#define IDC_MIDPOINT                    1000
#define IDC_WIDTH                       1001
#define ID_32771                        32771
#define ID_Invert                       32772
#define ID_32773                        32773
#define ID_Restore                      32774
#define ID_32775                        32775
#define ID_Stretching                   32776
#define ID_32777                        32777
#define ID_BitPlane                     32778
#define ID_32779                        32779
#define ID_Histo                        32780
#define ID_32781                        32781
#define ID_HIS                          32782
#define ID_Histo_Eq                     32783
#define ID_Histo_Equa                   32784
#define ID_32785                        32785
#define ID_32786                        32786
#define ID_32787                        32787
#define ID_Smoothing                    32788
#define ID_Sobel                        32789
#define ID_Laplace                      32790
#define ID_32791                        32791
#define ID_Gaussian                     32792
#define ID_GAUSSIAN_32793               32793
#define ID_GAUSSIAN_32794               32794
#define ID_Gaussian1D                   32795
#define ID_Gaussian2D                   32796
#define ID_32797                        32797
#define ID_CTWINDOWS_BONE               32798
#define ID_CTWINDOWS_LUNG               32799
#define ID_LUNG                         32800
#define ID_BONE                         32801
#define ID_CTWINDOWS_ADJUSTWINDOW       32802
#define ID_ADJUSTWINDOW                 32803

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        314
#define _APS_NEXT_COMMAND_VALUE         32804
#define _APS_NEXT_CONTROL_VALUE         1003
#define _APS_NEXT_SYMED_VALUE           310
#endif
#endif
